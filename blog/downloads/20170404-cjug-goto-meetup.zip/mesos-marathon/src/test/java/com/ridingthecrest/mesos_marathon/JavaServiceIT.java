package com.ridingthecrest.mesos_marathon;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class JavaServiceIT {
    
    private static String serviceUrl;
    
    @BeforeClass
    public static void beforeClass() throws Exception {
        serviceUrl = System.getProperty("service.url");
    }
    
    
    @Test
    public void testMetrics() throws Exception {
        Client client = ClientBuilder.newClient();
        Response response = client.target(serviceUrl)
                .path("api/memory")
                .request(MediaType.TEXT_PLAIN_TYPE)
                .get();
        assertEquals(Response.Status.OK.getStatusCode(), response.getStatus());
    }    

}
        
